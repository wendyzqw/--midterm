# nndl-project
神经网络期中作业 
项目内容 用CNN网络模型(自己设计或AlexNet或ResNet-18)在CIFAR-10上训练并测试
参考资料 https://github.com/WZMIAOMIAO/deep-learning-for-image-processing/tree/master/pytorch_classification/tensorboard_test
参考资料 https://blog.csdn.net/sunqiande88/article/details/80100891
