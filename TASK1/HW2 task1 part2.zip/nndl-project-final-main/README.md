# nndl-project-final
 对比cutmix, cutout, mixup三种方法以及baseline方法在CIFAR-10或CIFAR-100图像分类任务中的性能表现。
 
参考资料
mixup:https://github.com/facebookresearch/mixup-cifar10
cutout:https://github.com/uoguelph-mlrg/Cutout
cutmix:https://github.com/clovaai/CutMix-PyTorch
